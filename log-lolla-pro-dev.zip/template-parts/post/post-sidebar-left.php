<div class="post__sidebar post__sidebar--left">
  <?php get_template_part( 'template-parts/post/parts/post', 'date' ); ?>
</div>
