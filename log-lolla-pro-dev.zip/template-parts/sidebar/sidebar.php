<section id="sidebar" class="sidebar">
  <h3 hidden>Sidebar</h3>

  <?php get_sidebar(); ?>
</section>
