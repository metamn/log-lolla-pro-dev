<?php

/**
 * Template part for displaying the archives page
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Log_Lolla
 */

?>

<div class="archives-content">
  <?php the_content(); ?>
</div>
